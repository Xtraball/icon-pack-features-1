# icon-pack-features-1

Compatible with Siberian 4.6.1+

A complete selection for almost every SiberianCMS Feature.

![icons1](resources/docs/icons1.png)
![icons2](resources/docs/icons2.png)

Credits: Icon selection from [FlatIcon](www.flaticon.com)